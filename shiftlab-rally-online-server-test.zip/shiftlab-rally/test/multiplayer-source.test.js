const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'shiftlab-performance-online.html'), 'utf8');
const readme = fs.readFileSync(path.join(root, 'README-online.txt'), 'utf8');

test('server detects and removes stale WebSocket connections', () => {
  assert.match(server, /wss\.on\(['"]connection['"],\s*\(ws\)\s*=>/);
  assert.match(server, /ws\.ping\(/, 'server should ping clients to detect dead connections');
  assert.match(server, /ws\.terminate\(/, 'server should terminate clients that miss heartbeats');
});

test('client sends only on an open WebSocket', () => {
  assert.match(html, /function mpSend\(msg\)\s*\{\s*if\s*\(!mpSocket\s*\|\|\s*mpSocket\.readyState\s*!==\s*WebSocket\.OPEN\)\s*return false;/);
});

test('full rooms release the failed socket so the player can retry or leave', () => {
  assert.match(html, /if\s*\(tag\s*===\s*70[\s\S]{0,260}mpSocket\s*=\s*null[\s\S]{0,260}mpSetStatus\("full"\)/);
});

test('deployment guide explains that static hosting alone cannot run multiplayer', () => {
  assert.match(readme, /Node\.js/i);
  assert.match(readme, /WebSocket/i);
  assert.match(readme, /static hosting/i);
});
