# WorkGroup: Multiplayer reliability

## Goal
Reduce avoidable multiplayer disconnect and retry failures and document the required deployment topology.

## Change set
- `server.js`: heartbeat stale WebSocket clients and terminate clients that fail to respond.
- `shiftlab-performance-online.html`: send only on OPEN sockets; release a room-full socket cleanly.
- `test/multiplayer-source.test.js`: source-level regression checks using built-in `node:test`.
- `README-online.txt`: clear deployment steps and static-hosting limitation.

## Risks / limits
- This is not an authoritative simulation; clients still report their own positions.
- Live two-browser verification requires installing `ws` and running the server. Dependency installation timed out in this environment, so this limitation must be reported if unresolved.

## Acceptance checks
- `npm test` passes.
- `node --check server.js` passes.
- Browser client source passes `node --check` after extracting scripts if practical.
- README explains how to run and deploy the Node.js WebSocket server.
