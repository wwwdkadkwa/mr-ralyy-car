# Work log

## 2026-10-16 — Multiplayer connection reliability
- Added a server-side WebSocket heartbeat to detect half-open/stale clients.
- Configured a maximum WebSocket payload size.
- Guarded client sends so they only occur when the socket is OPEN.
- Fixed full-room handling to detach and close the rejected socket without triggering reconnect.
- Added Node built-in regression checks and deployment instructions.
- Local tests and syntax checks pass. Full integration test is still unverified because installing the `ws` dependency timed out in this environment.
