# Architecture

```mermaid
flowchart LR
  A[Browser game client] <-->|WebSocket /ws| B[Node.js server]
  A --> C[HTML/CSS/JavaScript UI and physics]
  B --> D[Player roster and state fan-out]
```

The server broadcasts client-reported player states; it does not run authoritative physics. A production deployment needs a Node.js host that supports WebSockets.
