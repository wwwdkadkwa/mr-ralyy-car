# Multiplayer reliability

## Requirements
- The server must detect WebSocket clients that disappear without a clean close and remove their stale player records.
- The browser must not attempt to send application messages while the WebSocket is connecting or closing.
- If the room is full, the browser must release the rejected socket and must not start an automatic reconnect loop for that full-room response.
- Deployment instructions must state that a static-only host cannot execute the Node.js WebSocket backend.

## VERIFY
- `npm test` passes.
- `node --check server.js` passes.
- All inline JavaScript blocks in the HTML pass syntax checks.
- Live two-client validation is performed before calling the deployed multiplayer experience verified.
