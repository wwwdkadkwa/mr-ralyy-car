# ShiftLab Performance — local workflow

Use test-first changes. For multiplayer work: reproduce or add a failing test, make the smallest fix, run all available tests, check JavaScript syntax, and document any environment limitations. Do not claim live multiplayer works until tested with two browser clients against a deployed Node.js WebSocket server.
