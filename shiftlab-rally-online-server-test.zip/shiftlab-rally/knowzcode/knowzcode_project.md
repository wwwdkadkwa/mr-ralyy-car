# Project

## Goal
ShiftLab Performance is a browser-based car game. Improve reliable online multiplayer connections and keep players' car state synchronized across clients.

## Architecture
Single-page HTML/CSS/JavaScript game served by a separate Node.js HTTP + WebSocket backend (`server.js`, `ws` package). Static hosting alone cannot run the WebSocket backend.

## Stack
- Language: JavaScript
- Runtime: Node.js
- Browser UI: single-page HTML/CSS/JavaScript
- Multiplayer transport: WebSocket (`ws`)
- Test runner: Node.js built-in `node:test`
- Build: none
