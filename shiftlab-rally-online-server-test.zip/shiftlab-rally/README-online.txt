ShiftLab Performance — online multiplayer

Requirements: Node.js 18+ and npm. The server uses the `ws` WebSocket package.

Run locally:
1. Install Node.js.
2. In this folder, run `npm install`.
3. Run `npm start`.
4. Open http://localhost:3000 in two browser tabs or on two devices on the same network. For another device, use the host computer's LAN IP and allow port 3000 through its firewall.

Deployment:
Deploy this whole folder to a Node.js host that supports long-lived WebSocket connections. Set the PORT environment variable if the host supplies one. The host must run `npm start` and route both HTTP and WebSocket traffic to the same service. A static hosting service that only uploads HTML/CSS/JS cannot run `server.js`, so online multiplayer will not work there unless the WebSocket backend is deployed separately and `window.SHIFTLAB_WS_URL` is configured to its secure `wss://` endpoint.

Security and testing notes:
The server relays client-reported positions; it is not an authoritative physics server. Test with at least two clients before sharing the deployment. Use HTTPS/WSS in production.
